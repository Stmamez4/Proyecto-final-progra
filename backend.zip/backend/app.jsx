const App = () => {
    return (
        <div className="container mt-5">
            <h1 className="text-center">Bienvenido al Sistema de Gestión de Biblioteca</h1>
            <p className="text-muted text-center">Este es un proyecto en desarrollo.</p>
        </div>
    );
};

export default App;
